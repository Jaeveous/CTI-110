#Jaeveous Hardy
#P4LAB1
#July 7, 2024
#Drawing shapes



import turtle
wn = turtle.Screen()
wn.bgcolor("lightgreen")

tess = turtle.Turtle()
tess.color("blue")
tess.pensize(3)


turtle.shape("turtle")
turtle.color("red")

for i in [0,1,2,3]:
    tess.forward(100)
    tess.left(90)
    
for i in range(3):
    tess.forward(300)
    tess.right(120)
 
    
   

turtle.exitonclick()
